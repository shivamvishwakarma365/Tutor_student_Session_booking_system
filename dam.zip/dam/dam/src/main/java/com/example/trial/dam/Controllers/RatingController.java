package com.example.trial.dam.Controllers;



import com.example.trial.dam.Dto.RatingDtoLayer;
import com.example.trial.dam.Services.NewRatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/ratings")
public class RatingController {

    private final NewRatingService ratingService;

    @Autowired
    public RatingController(NewRatingService ratingService) {
        this.ratingService = ratingService;
    }


    @PostMapping("/rate")
    public ResponseEntity<RatingDtoLayer> rateTutor(@RequestBody Map<String, Object> request) {
        Long sessionId = Long.valueOf(request.get("sessionId").toString());
        int ratingPoint = Integer.parseInt(request.get("ratingPoint").toString());
        String review = request.get("review").toString();

        RatingDtoLayer savedRating = ratingService.rateTutor(sessionId, ratingPoint, review);
        return ResponseEntity.ok(savedRating);
    }
//    @GetMapping("/tutor/{tutorId}/session-ratings")
//    public ResponseEntity<List<RatingDtoLayer>> getTutorSessionRatings(@PathVariable Long tutorId) {
//        List<RatingDtoLayer> tutorSessionRatings = ratingService.getAllTutorSessionRatings(tutorId);
//        return ResponseEntity.ok(tutorSessionRatings);
//    }

    @GetMapping("/tutor/{tutorId}/session-ratings")
    public ResponseEntity<List<Map<String, Object>>> getTutorSessionRatings(@PathVariable Long tutorId) {
        List<Map<String, Object>> tutorSessionRatings = ratingService.getAllTutorSessionRatings(tutorId);
        return ResponseEntity.ok(tutorSessionRatings);
    }




}

