package com.example.trial.dam.Controllers;

import com.example.trial.dam.Dto.SessionDTO;
import com.example.trial.dam.Models.Session;
import com.example.trial.dam.Repository.SessionRepository;
import com.example.trial.dam.Services.SessionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/sessions")
public class SessionController {

    private final SessionService sessionService;

    @Autowired
    public SessionController(SessionService sessionService) {
        this.sessionService = sessionService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<SessionDTO>> getAllSessions() {
        List<SessionDTO> sessions = sessionService.getAllSessions();
        return new ResponseEntity<>(sessions, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{sessionId}")
    public ResponseEntity<String> deleteSession(@PathVariable Long sessionId) {
        boolean deleted = sessionService.deleteSession(sessionId);
        if (deleted) {
            return new ResponseEntity<>("Session deleted successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Session not found or cannot be deleted", HttpStatus.BAD_REQUEST);
        }
    }


    @GetMapping("/tutor/{tutorId}")
    public ResponseEntity<List<SessionDTO>> getTutorSessions(@PathVariable Long tutorId) {
        List<SessionDTO> sessions = sessionService.getTutorSessions(tutorId);
        return new ResponseEntity<>(sessions, HttpStatus.OK);
    }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<SessionDTO>> getStudentSessions(@PathVariable Long studentId) {
        List<SessionDTO> sessions = sessionService.getStudentSessions(studentId);
        return new ResponseEntity<>(sessions, HttpStatus.OK);
    }

    @PutMapping("/cancel/{sessionId}")
    public ResponseEntity<String> cancelSession(@PathVariable Long sessionId) {
        if (sessionService.cancelSession(sessionId)) {
            return new ResponseEntity<>("Session canceled successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Session not found or cannot be canceled", HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/book")
    public ResponseEntity<Object> bookSession(@RequestBody BookingRequest bookingRequest) {
        // Access bookingRequest fields like bookingRequest.getTutorId(), etc.
        SessionDTO sessionDTO = sessionService.bookSession(
                bookingRequest.getTutorId(),
                bookingRequest.getStudentId(),
                bookingRequest.getStartTime(),
                bookingRequest.getEndTime(),
                bookingRequest.getSubject()
        );

        if (sessionDTO != null) {
            return ResponseEntity.status(HttpStatus.CREATED).body("booked the session");
        } else {
            return ResponseEntity.badRequest().body("Unable to book a session.");
        }
    }


    // Get the count of scheduled sessions for a particular tutor
    @GetMapping("/tutor/{tutorId}/count-scheduled-sessions")
    public ResponseEntity<Long> countTutorScheduledSessions(@PathVariable Long tutorId) {
        long count = sessionService.countTutorScheduledSessions(tutorId);
        return ResponseEntity.ok(count);
    }

    // Get the count of scheduled sessions for a particular student
    @GetMapping("/student/{studentId}/count-scheduled-sessions")
    public ResponseEntity<Long> countStudentScheduledSessions(@PathVariable Long studentId) {
        long count = sessionService.countStudentScheduledSessions(studentId);
        return ResponseEntity.ok(count);
    }

    @GetMapping("/student/{studentId}/sessions-by-status")
    public ResponseEntity<Map<String, List<String>>> getStudentSessionsByStatus(@PathVariable Long studentId) {
        Map<String, List<String>> sessionsByStatus = sessionService.getStudentSessionsByStatus(studentId);
        return new ResponseEntity<>(sessionsByStatus, HttpStatus.OK);
    }

    @GetMapping("/tutor/{tutorId}/sessions-by-status")
    public ResponseEntity<Map<String, List<String>>> getTutorSessionsByStatus(@PathVariable Long tutorId) {
        Map<String, List<String>> sessionsByStatus = sessionService.getTutorSessionsByStatus(tutorId);
        return new ResponseEntity<>(sessionsByStatus, HttpStatus.OK);
    }
    @GetMapping("/student/{studentId}/scheduled-session-timings")
    public ResponseEntity<List<String>> getStudentScheduledSessionTimings(@PathVariable Long studentId) {
        List<String> scheduledSessionTimings = sessionService.getStudentScheduledSessionsTimings(studentId);
        return new ResponseEntity<>(scheduledSessionTimings, HttpStatus.OK);
    }
    @GetMapping("/tutor/{tutorId}/scheduled-session-timings")
    public ResponseEntity<List<String>> getTutorScheduledSessionTimings(@PathVariable Long tutorId) {
        List<String> scheduledSessionTimings = sessionService.getTutorScheduledSessionsTimings(tutorId);
        return new ResponseEntity<>(scheduledSessionTimings, HttpStatus.OK);
    }




}
