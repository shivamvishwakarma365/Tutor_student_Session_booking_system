package com.example.trial.dam.Dto;

public class TutorDTO {
    private String tutorName;
    private String tutorExpertise;
    private String tutorEmail;
    private String tutorAvailability;

    public TutorDTO() {
    }

    public TutorDTO(String tutorName, String tutorExpertise, String tutorEmail, String tutorAvailability) {
        this.tutorName = tutorName;
        this.tutorExpertise = tutorExpertise;
        this.tutorEmail = tutorEmail;
        this.tutorAvailability = tutorAvailability;
    }

    public String getTutorName() {
        return tutorName;
    }

    public void setTutorName(String tutorName) {
        this.tutorName = tutorName;
    }

    public String getTutorExpertise() {
        return tutorExpertise;
    }

    public void setTutorExpertise(String tutorExpertise) {
        this.tutorExpertise = tutorExpertise;
    }

    public String getTutorEmail() {
        return tutorEmail;
    }

    public void setTutorEmail(String tutorEmail) {
        this.tutorEmail = tutorEmail;
    }

    public String getTutorAvailability() {
        return tutorAvailability;
    }

    public void setTutorAvailability(String tutorAvailability) {
        this.tutorAvailability = tutorAvailability;
    }
}
