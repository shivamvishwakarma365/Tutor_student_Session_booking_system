package com.example.trial.dam.Models;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;

@Entity
@Table(name = "sessions")
public class Session {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "session_id")
    private Long sessionId;

    @ManyToOne
    @JoinColumn(name = "tutor_id")
    @JsonIgnoreProperties("sessions")
    private Tutor tutor;

    @ManyToOne
    @JoinColumn(name = "student_id")
    @JsonIgnoreProperties("sessions")
    private Student student;

    @Column(name = "subject")
    private String subject;

    @Column(name = "start_time")
    private LocalDateTime startTime;

    @Column(name = "end_time")
    private LocalDateTime endTime;

    @Column(name = "status")
    private String status;


    @OneToMany(mappedBy = "sessions", cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<Ratings> ratings;

    public Long getSessionId() {
        return sessionId;
    }

    public void setSessionId(Long sessionId) {
        this.sessionId = sessionId;
    }

    public Tutor getTutor() {
        return tutor;
    }

    public void setTutor(Tutor tutor) {
        this.tutor = tutor;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public Session(Long sessionId, Tutor tutor, Student student, String subject, LocalDateTime startTime, LocalDateTime endTime, String status, List<Ratings> ratings) {
        this.sessionId = sessionId;
        this.tutor = tutor;
        this.student = student;
        this.subject = subject;
        this.startTime = startTime;
        this.endTime = endTime;
        this.status = status;
        this.ratings = ratings;
    }

    public Session() {
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<Ratings> getRatings() {
        return ratings;
    }

    public void setRatings(List<Ratings> ratings) {
        this.ratings = ratings;
    }




}
