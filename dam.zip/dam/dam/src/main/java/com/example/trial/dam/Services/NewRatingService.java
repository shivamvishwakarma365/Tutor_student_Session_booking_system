package com.example.trial.dam.Services;

import com.example.trial.dam.Dto.*;
import com.example.trial.dam.Models.Ratings;
import com.example.trial.dam.Models.Session;
import com.example.trial.dam.Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class NewRatingService {

    @Autowired
    private TutorRepository tutorRepository;
    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private SessionRepository sessionRepository;
    @Autowired
    private RatingRepository ratingRepository;


    public RatingDtoLayer rateTutor(Long sessionId, int ratingPoint, String review) {
        Session sessions = sessionRepository.findById(sessionId).orElseThrow(() -> new RuntimeException("Session not found"));

        if (sessions.getSessionId() != sessionId) {
            throw new RuntimeException("No booked session as such to rate");
        }

        Ratings ratings = new Ratings();
        ratings.setSessions(sessions);
        ratings.setRatingPoint(ratingPoint);
        ratings.setReview(review);
        Ratings savedRating = ratingRepository.save(ratings);

        sessions.setStatus("Completed");
        sessionRepository.save(sessions);


        return convertToDto(savedRating);
    }

//    public List<RatingDtoLayer> getAllTutorSessionRatings(Long tutorId) {
//        List<Session> tutorSessions = sessionRepository.findByTutorTutorId(tutorId);
//        List<RatingDtoLayer> tutorSessionRatings = new ArrayList<>();
//
//        for (Session session : tutorSessions) {
//            List<Ratings> sessionRatings = ratingRepository.findBySessions(session);
//            for (Ratings ratings : sessionRatings) {
//                tutorSessionRatings.add(convertToDto(ratings));
//            }
//        }
//
//        return tutorSessionRatings;
//    }
    public List<Map<String, Object>> getAllTutorSessionRatings(Long tutorId) {
        List<Session> tutorSessions = sessionRepository.findByTutorTutorId(tutorId);
        List<Map<String, Object>> tutorSessionRatings = new ArrayList<>();

        for (Session session : tutorSessions) {
            List<Ratings> sessionRatings = ratingRepository.findBySessions(session);
            for (Ratings ratings : sessionRatings) {
                Map<String, Object> ratingMap = new HashMap<>();
                ratingMap.put("ratingId", ratings.getRatingId());
                ratingMap.put("ratingPoint", ratings.getRatingPoint());
                ratingMap.put("review", ratings.getReview());
                tutorSessionRatings.add(ratingMap);
            }
        }

        return tutorSessionRatings;
    }

    private RatingDtoLayer convertToDto(Ratings ratings) {
        RatingDtoLayer dto = new RatingDtoLayer();
        dto.setSessions(ratings.getSessions());
        dto.setTutor(ratings.getSessions().getTutor());
        dto.setStudent(ratings.getSessions().getStudent());
        dto.setRatingId(ratings.getRatingId());
        dto.setRatingPoint(ratings.getRatingPoint());
        dto.setReview(ratings.getReview());
        return dto;
    }

    private Ratings convertToEntity(RatingDtoLayer dto) {
        Ratings ratings = new Ratings();
        ratings.setSessions(dto.getSessions());
        ratings.setRatingPoint(dto.getRatingPoint());
        ratings.setReview(dto.getReview());
        return ratings;
    }

}
