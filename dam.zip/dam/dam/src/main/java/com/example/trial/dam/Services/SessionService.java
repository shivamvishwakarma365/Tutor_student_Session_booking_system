package com.example.trial.dam.Services;

import com.example.trial.dam.Dto.SessionDTO;
import com.example.trial.dam.Models.Session;
import com.example.trial.dam.Repository.SessionRepository;
import com.example.trial.dam.Repository.TutorRepository;
import com.example.trial.dam.Repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SessionService {

    private final SessionRepository sessionRepository;
    private final TutorRepository tutorRepository;
    private final StudentRepository studentRepository;

    @Autowired
    public SessionService(SessionRepository sessionRepository, TutorRepository tutorRepository, StudentRepository studentRepository) {
        this.sessionRepository = sessionRepository;
        this.tutorRepository = tutorRepository;
        this.studentRepository = studentRepository;
    }
    public SessionDTO bookSession(Long tutorId, Long studentId, LocalDateTime startTime, LocalDateTime endTime, String subject) {
        boolean isTutorAvailable = tutorIsAvailable(tutorId, startTime, endTime);
      //if tutor is there or not like checking if he is free or not
        if (isTutorAvailable) {
            Session session = new Session();
            session.setTutor(tutorRepository.findById(tutorId).orElse(null));
            session.setStudent(studentRepository.findById(studentId).orElse(null));
            session.setStartTime(startTime);
            session.setEndTime(endTime);
            session.setSubject(subject);
            session.setStatus("Scheduled");


            Session savedSession = sessionRepository.save(session);

            return convertToDTO(savedSession);
        } else {

            return null;
        }
    }


    public List<SessionDTO> getTutorSessions(Long tutorId) {
        List<Session> sessions = sessionRepository.findByTutorTutorId(tutorId);
        return sessions.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }



    // full fetch all sessions for a student
    public List<SessionDTO> getStudentSessions(Long studentId) {
        List<Session> sessions = sessionRepository.findByStudentStudentId(studentId);
        return sessions.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // can a session by using the id thing
    public boolean cancelSession(Long sessionId) {
        Optional<Session> sessionOptional = sessionRepository.findById(sessionId);

        if (sessionOptional.isPresent()) {
            Session session = sessionOptional.get();
            session.setStatus("Cancelled"); // Update the session status to "Cancelled"
            sessionRepository.save(session);
            return true;
        }

        return false; // Session not found
    }

    // its a helper method for the above methods
    private boolean tutorIsAvailable(Long tutorId, LocalDateTime startTime, LocalDateTime endTime) {
        List<Session> tutorSessions = sessionRepository.findScheduledSessionsByTutorAndTime(tutorId, startTime, endTime);
        return tutorSessions.isEmpty();
    }


    public List<SessionDTO> getAllSessions() {
        List<Session> sessions = sessionRepository.findAll();
        return sessions.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }


    public boolean deleteSession(Long sessionId) {
        Optional<Session> sessionOptional = sessionRepository.findById(sessionId);

        if (sessionOptional.isPresent()) {
            Session session = sessionOptional.get();
            sessionRepository.delete(session);
            return true;
        }

        return false;
    }


    public long countTutorScheduledSessions(Long tutorId) {
        List<Session> tutorSessions = sessionRepository.findByTutorTutorId(tutorId);
        return tutorSessions.stream()
                .filter(session -> "Scheduled".equals(session.getStatus()))
                .count();
    }

    public long countStudentScheduledSessions(Long studentId) {
        List<Session> studentSessions = sessionRepository.findByStudentStudentId(studentId);
        return studentSessions.stream()
                .filter(session -> "Scheduled".equals(session.getStatus()))
                .count();
    }


        public Map<String, List<String>> getStudentSessionsByStatus(Long studentId) {

            List<Session> sessions = sessionRepository.findByStudentStudentId(studentId);

            Map<String, List<String>> sessionsByStatus = new HashMap<>();
            sessionsByStatus.put("Scheduled", new ArrayList<>());
            sessionsByStatus.put("Cancelled", new ArrayList<>());
            sessionsByStatus.put("Completed", new ArrayList<>());

            for (Session session : sessions) {
                String status = session.getStatus();
                String timing = session.getStartTime() + " - " + session.getEndTime();

                if ("Scheduled".equals(status)) {
                    sessionsByStatus.get("Scheduled").add(timing);
                } else if ("Cancelled".equals(status)) {
                    sessionsByStatus.get("Cancelled").add(timing);
                } else if ("Completed".equals(status)) {
                    sessionsByStatus.get("Completed").add(timing);
                }
            }

            return sessionsByStatus;
        }
    public Map<String, List<String>> getTutorSessionsByStatus(Long tutorId) {
        List<Session> sessions = sessionRepository.findByTutorTutorId(tutorId);

        Map<String, List<String>> sessionsByStatus = new HashMap<>();
        sessionsByStatus.put("Scheduled", new ArrayList<>());
        sessionsByStatus.put("Cancelled", new ArrayList<>());
        sessionsByStatus.put("Completed", new ArrayList<>());

        for (Session session : sessions) {
            String status = session.getStatus();
            String timing = session.getStartTime() + " - " + session.getEndTime();

            if ("Scheduled".equals(status)) {
                sessionsByStatus.get("Scheduled").add(timing);
            } else if ("Cancelled".equals(status)) {
                sessionsByStatus.get("Cancelled").add(timing);
            } else if ("Completed".equals(status)) {
                sessionsByStatus.get("Completed").add(timing);
            }
        }

        return sessionsByStatus;
    }

    public List<String> getStudentScheduledSessionsTimings(Long studentId) {
        List<Session> sessions = sessionRepository.findByStudentStudentId(studentId);
        List<String> scheduledSessionTimings = new ArrayList<>();

        for (Session session : sessions) {
            if ("Scheduled".equals(session.getStatus())) {
                String timing = session.getStartTime() + " - " + session.getEndTime();
                String tutorName = session.getTutor().getTutorName();
                scheduledSessionTimings.add(timing + " with Tutor: " + tutorName);
            }
        }

        return scheduledSessionTimings;
    }
    public List<String> getTutorScheduledSessionsTimings(Long tutorId) {
        List<Session> sessions = sessionRepository.findByTutorTutorId(tutorId);
        List<String> scheduledSessionTimings = new ArrayList<>();

        for (Session session : sessions) {
            if ("Scheduled".equals(session.getStatus())) {
                String timing = session.getStartTime() + " - " + session.getEndTime();
                String studentName = session.getStudent().getStudentName();
                scheduledSessionTimings.add(timing + " with Student: " + studentName);
            }
        }

        return scheduledSessionTimings;
    }




    private SessionDTO convertToDTO(Session session) {
        SessionDTO sessionDTO = new SessionDTO();
        sessionDTO.setSessionId(session.getSessionId());
        sessionDTO.setTutor(session.getTutor());
        sessionDTO.setStudent(session.getStudent());
        sessionDTO.setStartTime(session.getStartTime());
        sessionDTO.setEndTime(session.getEndTime());
        sessionDTO.setSubject(session.getSubject());
        sessionDTO.setStatus(session.getStatus());
        return sessionDTO;
    }
}
