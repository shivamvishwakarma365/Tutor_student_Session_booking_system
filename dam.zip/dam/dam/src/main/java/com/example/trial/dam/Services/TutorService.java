package com.example.trial.dam.Services;


import java.time.LocalDateTime;
import com.example.trial.dam.Dto.TutorDTO;
import com.example.trial.dam.Models.Ratings;
import com.example.trial.dam.Models.Session;
import com.example.trial.dam.Models.Student;
import com.example.trial.dam.Models.Tutor;
import com.example.trial.dam.Repository.RatingRepository;
import com.example.trial.dam.Repository.SessionRepository;
import com.example.trial.dam.Repository.StudentRepository;
import com.example.trial.dam.Repository.TutorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class TutorService {
    @Autowired
    private TutorRepository tutorRepository;

    @Autowired
    private SessionRepository sessionRepository;

    @Autowired
    private RatingRepository ratingRepository;

    @Autowired
    private StudentRepository studentRepository;
    // Create
    public Tutor createTutor(TutorDTO tutorDTO) {
        Tutor tutor = new Tutor();
        tutor.setTutorName(tutorDTO.getTutorName());
        tutor.setTutorExpertise(tutorDTO.getTutorExpertise());
        tutor.setTutorEmail(tutorDTO.getTutorEmail());
        tutor.setTutorAvailability(tutorDTO.getTutorAvailability()); // Set the tutorAvailability field
        return tutorRepository.save(tutor);
    }


    // Update
    public Tutor updateTutor(Long tutorId, TutorDTO updatedTutorDTO) {
        Optional<Tutor> existingTutorOptional = tutorRepository.findById(tutorId);
        if (existingTutorOptional.isPresent()) {
            Tutor existingTutor = existingTutorOptional.get();
            existingTutor.setTutorName(updatedTutorDTO.getTutorName());
            existingTutor.setTutorExpertise(updatedTutorDTO.getTutorExpertise());
            existingTutor.setTutorEmail(updatedTutorDTO.getTutorEmail());
            return tutorRepository.save(existingTutor);
        }
        return null; // Handle not found case
    }
    //particular teacher
    public Optional<Tutor> getTutorById(Long tutorId) {
        return tutorRepository.findById(tutorId);
    }

    // Delete
    public void deleteTutor(Long tutorId) {
        tutorRepository.deleteById(tutorId);
    }

    // Method to retrieve a list of all tutors
    public List<Tutor> getAllTutors() {
        return tutorRepository.findAll();
    }

    // Method to retrieve tutors by subject
    public List<Tutor> getTutorsByTutorExpertise(String tutorExpertise) {
        return tutorRepository.findByTutorExpertise(tutorExpertise);
    }








}

